package Stream;

public class VidChar extends STRUCT
{
public byte ascii, color;
}
