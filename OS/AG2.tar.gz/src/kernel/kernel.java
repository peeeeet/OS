package kernel;
import Stream.Output;
public class Kernel {
	
private static int grey = 0x07;
private static int brown = 0x06;
private static int viol = 0x05;
private static int red = 0x04;
private static int tur = 0x03;
private static int green = 0x02;
private static int blue = 0x01;
private static int black = 0x00;


	
	public static void main()
	{
	byte testby1 = -127;
	byte testby2 = 127;
	long testln1 = 9223372036854775807L;
	long testln2 = -9223372036854775808L;
	short testsh1 = 32767;
	short testsh2 = -32767;
	int testint1 = 2147483647;
	int testint2 = -2147483647;
	
		
	Output out1 = new Output();
	Output out2 = new Output();
	
	out1.clearScreen(green);
	out1.setColor(red, black);
	out1.println("TEST PRINTLN");
	out1.setColor(tur, black);
	out1.println(testint1);
	out1.println('D');
	out1.println(testln1);
	out1.println("TEST");
	out2.setColor(red, black);
	out2.println(' ');
	out2.println("TEST PRINT");
	out2.setColor(green, black);
	out2.print("HEX BYTE");
	out2.setCursor(10, 0);
	out2.printHex(testby1);
	out2.setCursor(0, 1);
	out2.printHex(testby2);
	out2.println();
	out2.print("LONG");
	out2.setCursor(10, 0);
	out2.print(testln1);
	out2.setCursor(0, 1);
	out2.print(testln2);
	out2.println();
	out2.print("HEX LONG");
	out2.setCursor(10, 0);
	out2.printHex(testln1);
	out2.setCursor(0, 1);
	out2.printHex(testln2);
	out2.println();
	out2.print("HEX SHORT");
	out2.setCursor(10, 0);
	out2.printHex(testsh1);
	out2.setCursor(0, 1);
	out2.printHex(testsh2);
	out2.println();
	out2.print("INT");
	out2.setCursor(10, 0);
	out2.print(testint1);
	out2.setCursor(0, 1);
	out2.print(testint2);
	out2.println();
	out2.print("HEX INT");
	out2.setCursor(10, 0);
	out2.printHex(testint1);
	out2.setCursor(0, 1);
	out2.printHex(testint2);
	out2.println();
	out2.print("STRING");
	out2.setCursor(10, 0);
	out2.print("TEST");
	out1.setColor(red, black);
	out1.println(' ');
	out1.println(' ');
	out1.println("TEST NEXT OBJECT");
	out1.println(' ');
	out1.setColor(viol, black);
	out1.print("out1:");
	out1.setCursor(5, 0);
	out1.print(MAGIC.cast2Ref(out1._r_next));
	out1.println(' ');
	out1.print("out2:");
	out1.setCursor(5, 0);
	out1.print(MAGIC.cast2Ref(out2));
	out1.println(' ');
		
	}

}
