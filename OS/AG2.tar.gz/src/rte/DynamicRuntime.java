package rte;
import java.lang.*;
public class DynamicRuntime {
private static int nextObjectAddress = 0;
private static Object last_obj;
	  public static Object newInstance(int scalarSize, int relocEntries, SClassDesc type) 
	  	  {	
		  
		  // Variablen 
		  int startAddress;
		  int refSize;
		  int memsize;
		  int adrlastObj;
		  Object lastobj;
		  
		  
		  // Startaddresse
		  if(nextObjectAddress==0)
		  {
			  // Start & Größe des Speicherabbilds holen
			  // Berechnen anhand der Größen neue Startaddresse
			  startAddress = MAGIC.imageBase + MAGIC.rMem32(MAGIC.imageBase + 4);
			  
			  // Auf 4Byte Alignieren
			  while(startAddress % 4 != 0) startAddress++;
			  
			  // Adresse & Objekt von Klassendiskriptor
			  adrlastObj = MAGIC.rMem32(MAGIC.imageBase + 8);
			  lastobj = MAGIC.cast2Obj(adrlastObj);
		  }
		  else
		  {
			  startAddress = nextObjectAddress;
		      lastobj = last_obj;
		  }
		  
		  // Größe berechnen
		  refSize = relocEntries * 4;
		  memsize = scalarSize + refSize;
		  
		  // Auf 4Byte Alignieren
		  while(memsize % 4 != 0) memsize++;
		  
		  // Speicherbereich festlegen
		  nextObjectAddress += memsize;
		  
		  // Speicherbereich initialisieren
		  for(int i=startAddress; i<nextObjectAddress; i+=4) 
			  {
			  MAGIC.wMem32(i, 0);
			  }
		  
		  // Object Variable initialisieren
		  Object obj;
		  obj = MAGIC.cast2Obj(startAddress+refSize);
		  
		  // Ref und Scalar Größen im Obj speichern
		  MAGIC.assign(obj._r_scalarSize , refSize); 
		  MAGIC.assign(obj._r_relocEntries , relocEntries);
		  MAGIC.assign(obj._r_type , type);
		  
		  // Nächstes Objekt
		  MAGIC.assign(lastobj._r_next, obj);
		  last_obj = obj;

		  return obj;
		  }
	  
	  public static SArray newArray(int length, int arrDim, int entrySize,
	      int stdType, Object unitType) { while(true); }
	  
	  public static void newMultArray(SArray[] parent, int curLevel,
	      int destLevel, int length, int arrDim, int entrySize, int stdType,
	      Object unitType) { while(true); }
	  
	  public static boolean isInstance(Object o, SClassDesc dest,
	      boolean asCast) { while(true); }
	  
	  public static SIntfMap isImplementation(Object o, SIntfDesc dest,
	      boolean asCast) { while(true); }
	  
	  public static boolean isArray(SArray o, int stdType,
	      Object unitType, int arrDim, boolean asCast) { while(true); }
	  
	  public static void checkArrayStore(Object dest,
	      SArray newEntry) { while(true); }
	}
