package rte;

public class SIntfDesc
{

}
