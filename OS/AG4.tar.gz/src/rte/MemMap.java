package rte;

public class MemMap {
public long base;
public long len;
public int type;
}
