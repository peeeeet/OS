package rte;


public class SIntfMap 
{
	  public SIntfDesc owner;
	  public SIntfMap next;
}
