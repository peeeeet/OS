package rte;


public class SClassDesc 
{
	  public SClassDesc parent;
	  public SIntfMap implementations;
}