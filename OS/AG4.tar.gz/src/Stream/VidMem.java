package Stream;


public class VidMem extends STRUCT {
@SJC(count=2000)
VidChar[] digit;
}