package Stream;

import kernel.Display;

public class Output {
	private final static int VIDSTART = 0xB8000;
	private static int xSize = 80;
	private static int ySize = 23;
	private static int aciiPosInt = 48;
	private static int aciiPosHex = 55;
	private int start = 0;
	private int end = 0;
	private int mode = 0;
	private boolean trig = false;
	private VidMem vidMem = (VidMem) MAGIC.cast2Struct(VIDSTART);

	public Output() {
		setMode(1);
	}

	public Output(int m) {
		setMode(m);
	}

	public void setMode(int m) {
		// 0 Head
		if (m == 0) {
			mode = 0;
			start = 0;
			end = 80;
		}
		// 1 Body
		if (m == 1) {
			mode = 1;
			start = 80;
			end = 1920;
		}
		// 2 Foot
		if (m == 2) {
			mode = 2;
			start = 1920;
			end = 2000;
		}

	}

	public void setColor(int fg, int bg) {
		if (mode == 0) {
			Display.Instance().colMode0.setColor(fg, bg);
		} else if (mode == 1) {
			Display.Instance().colMode1.setColor(fg, bg);
		} else if (mode == 2) {
			Display.Instance().colMode2.setColor(fg, bg);
		}

	}
	
	public void setAreaColor(int x1, int x2, int y1, int y2, int fg, int bg) {
		int pos = start + x1 + y1*80;
		int pos2 = start + x2 + y2*80;
		
			if (pos < start || pos >= end)
				pos = start;
			
			if (pos2 < start || pos2 >= end)
				pos2 = start;

			while(pos != pos2)
			{
			vidMem.digit[pos++].color  = Color.getColor(fg, bg);
			}
	}

	public void setCursorAbs(int newX, int newY) {
		if (mode == 0) {
			VidPos.poshead = start;
			VidPos.poshead = VidPos.poshead
					+ (newX);
			if (VidPos.poshead < start
					|| VidPos.poshead >= end)
				VidPos.poshead = start;
		}
		if (mode == 1) {
			VidPos.posbody = start;
			VidPos.posbody = VidPos.posbody
					+ (newY * 80 + newX);
			if (VidPos.posbody < start
					|| VidPos.posbody >= end)
				VidPos.posbody = start;
		}
		if (mode == 2) {
			VidPos.posfoot = start;
			VidPos.posfoot = VidPos.posfoot
					+ (newX);
			if (VidPos.posfoot < start
					|| VidPos.posfoot >= end)
				VidPos.posfoot = start;
		}

	}

	public void setCursor(int newX, int newY) {
		int y;
		int x;

		if (mode == 0) {
			if ((char) vidMem.digit[VidPos.poshead].ascii == ' ')
				vidMem.digit[VidPos.poshead].color = Display
						.Instance().colMode0.col();

			x = VidPos.poshead % xSize;
			x += newX;
			if (VidPos.poshead < start
					|| VidPos.poshead >= end)
				VidPos.poshead = start;
		}
		if (mode == 1) {
			if ((char) vidMem.digit[VidPos.posbody].ascii == ' ')
				vidMem.digit[VidPos.posbody].color = Display
						.Instance().colMode1.col();

			y = VidPos.posbody / xSize;
			x = VidPos.posbody % xSize;
			y += newY;
			x += newX;
			VidPos.posbody = x + y * xSize;
			if (VidPos.posbody < start
					|| VidPos.posbody >= end)
				VidPos.posbody = start;
		}
		if (mode == 2) {
			VidPos.getInstance();
			if ((char) vidMem.digit[VidPos.posfoot].ascii == ' ')
				vidMem.digit[VidPos.posfoot].color = Display
						.Instance().colMode2.col();

			x = VidPos.posfoot % xSize;
			x += newX;
			VidPos.posfoot = x;
			if (VidPos.posfoot < start
					|| VidPos.posfoot >= end)
				VidPos.posfoot = start;
		}

	}

	public void setSpace() {
		int pos;

		if (mode == 0) {
			pos = VidPos.poshead;
			for (int i = end; i > pos; i--) {
				vidMem.digit[i].ascii = vidMem.digit[i - 1].ascii;
				vidMem.digit[i].color = vidMem.digit[i - 1].color;
			}
			vidMem.digit[VidPos.poshead].color = Display
					.Instance().colMode0.col();
			vidMem.digit[VidPos.poshead++].ascii = ' ';
			if (VidPos.poshead < start
					|| VidPos.poshead >= end)
				VidPos.poshead = start;
		}
		if (mode == 1) {
			pos = VidPos.posbody;
			for (int i = end; i > pos; i--) {
				vidMem.digit[i].ascii = vidMem.digit[i - 1].ascii;
				vidMem.digit[i].color = vidMem.digit[i - 1].color;
			}
			vidMem.digit[VidPos.posbody].color = Display
					.Instance().colMode1.col();
			vidMem.digit[VidPos.posbody++].ascii = ' ';
			if (VidPos.posbody < start
					|| VidPos.posbody >= end)
				VidPos.posbody = start;
		}
		if (mode == 2) {
			pos = VidPos.posfoot;
			for (int i = end; i > pos; i--) {
				vidMem.digit[i].ascii = vidMem.digit[i - 1].ascii;
				vidMem.digit[i].color = vidMem.digit[i - 1].color;
			}
			vidMem.digit[VidPos.posfoot].color = Display
					.Instance().colMode2.col();
			vidMem.digit[VidPos.posfoot++].ascii = ' ';
			if (VidPos.posfoot < start
					|| VidPos.posfoot >= end)
				VidPos.posfoot = start;
		}

	}

	public void removeChar() {
		int pos;

		if (mode == 0) {
			pos = VidPos.poshead;
			for (int i = pos; i < end - 1; i++) {
				vidMem.digit[i].ascii = vidMem.digit[i + 1].ascii;
				vidMem.digit[i].color = vidMem.digit[i + 1].color;
			}
			if (VidPos.poshead < start
					|| VidPos.poshead >= end)
				VidPos.poshead = start;
		}
		if (mode == 1) {
			pos = VidPos.posbody;
			for (int i = pos; i < end - 1; i++) {
				vidMem.digit[i].ascii = vidMem.digit[i + 1].ascii;
				vidMem.digit[i].color = vidMem.digit[i + 1].color;
			}
			if (VidPos.posbody < start
					|| VidPos.posbody >= end)
				VidPos.posbody = start;
		}
		if (mode == 2) {
			pos = VidPos.posfoot;
			for (int i = pos; i < end - 1; i++) {
				vidMem.digit[i].ascii = vidMem.digit[i + 1].ascii;
				vidMem.digit[i].color = vidMem.digit[i + 1].color;
			}
			if (VidPos.posfoot < start
					|| VidPos.posfoot >= end)
				VidPos.posfoot = start;
		}

	}

	public void setPos1() {
		int y;
		int x;

		if (mode == 0) {
			x = 0;
			VidPos.poshead = x;
			if (VidPos.poshead < start
					|| VidPos.poshead >= end)
				VidPos.poshead = start;
		}
		if (mode == 1) {
			x = VidPos.posbody % xSize;
			VidPos.posbody = VidPos.posbody - x;
			if (VidPos.posbody < start
					|| VidPos.posbody >= end)
				VidPos.posbody = start;
		}
		if (mode == 2) {
			x = 0;
			VidPos.posfoot = x;
			if (VidPos.posfoot < start
					|| VidPos.posfoot >= end)
				VidPos.posfoot = start;
		}

	}

	public void print(String str) {

		for (int i = 0; i < str.length(); i++)
			print(str.charAt(i));

	}

	public void print(char c) {
		if (mode == 0) {
			if (VidPos.poshead < start
					|| VidPos.poshead >= end)
				VidPos.poshead = start;
			vidMem.digit[VidPos.poshead].ascii = (byte) c;
			vidMem.digit[VidPos.poshead++].color = Display
					.Instance().colMode0.col();
		}
		if (mode == 1) {
			if (VidPos.posbody < start
					|| VidPos.posbody >= end)
				VidPos.posbody = start;
			vidMem.digit[VidPos.posbody].ascii = (byte) c;
			vidMem.digit[VidPos.posbody++].color = Display
					.Instance().colMode1.col();
		}
		if (mode == 2) {
			if (VidPos.posfoot < start
					|| VidPos.posfoot >= end)
				VidPos.posfoot = start;
			vidMem.digit[VidPos.posfoot].ascii = (byte) c;
			vidMem.digit[VidPos.posfoot++].color = Display
					.Instance().colMode2.col();
		}
	}

	public void print(int x) {

		// Schreibe - wenn x < 0
		if (x < 0)
			print('-');

		if (x != 0) {
			// Zahl in Char umwandeln
			rekint2char(x);
		}
		// Wenn Zahl = 0 dann Sonderfall
		else {
			print((char) (aciiPosInt));
		}
	}

	public void print(long x) {
		// Schreibe - wenn x < 0
		if (x < 0)
			print('-');

		if (x != 0) {
			// Zahl in Char umwandeln
			reklong2char(x);
		}
		// Wenn Zahl = 0 dann Sonderfall
		else {
			print((char) (aciiPosInt));
		}

	}

	public void printHex(byte b) {
		int m = 0;
		// Rekursion mit Abbruchbedingung bei == 0
		if ((m = b >>> 4) != 0)
			printHex(m);

		print((char) ((m = b & 0x0F) + (m < 10 ? aciiPosInt : aciiPosHex)));
	}

	public void printHex(short s) {
		int m = 0;
		// Rekursion mit Abbruchbedingung bei == 0
		if ((m = s >>> 4) != 0)
			printHex(m);

		print((char) ((m = s & 0x0F) + (m < 10 ? aciiPosInt : aciiPosHex)));

	}

	public void printHex(int x) {
		int m = 0;
		// Rekursion mit Abbruchbedingung bei == 0
		if ((m = x >>> 4) != 0)
			printHex(m);

		print((char) ((m = x & 0x0F) + (m < 10 ? aciiPosInt : aciiPosHex)));
	}

	public void printHex(long x) {
		long m = 0;
		// Rekursion mit Abbruchbedingung bei == 0
		if ((m = x >>> 4) != 0)
			printHex(m);

		print((char) ((m = x & 0x0F) + (m < 10 ? aciiPosInt : aciiPosHex)));
	}

	public void println() {
		if (VidPos.posbody % xSize != 0)
			VidPos.posbody += (xSize - VidPos.posbody
					% xSize);
	}

	public void printMemory() {

	}

	public void triggerCursor() {
		if (trig) {
			if (mode == 0) {

				vidMem.digit[VidPos.poshead].color = Display
						.Instance().colMode0.col();
			}
			if (mode == 1) {

				vidMem.digit[VidPos.posbody].color = Display
						.Instance().colMode1.col();
			}
			if (mode == 2) {
				vidMem.digit[VidPos.posfoot].color = Display
						.Instance().colMode2.col();
			}
			trig = false;
		} else {
			if (mode == 0) {
				vidMem.digit[VidPos.poshead].color = Display
						.Instance().colTrigMode0.col();
			}
			if (mode == 1) {

				vidMem.digit[VidPos.posbody].color = Display
						.Instance().colTrigMode1.col();
			}
			if (mode == 2) {
				vidMem.digit[VidPos.posfoot].color = Display
						.Instance().colTrigMode2.col();
			}
			trig = true;
		}
	}

	public void printNewLine() {
		if ((char) vidMem.digit[VidPos.posbody].ascii == ' ') {
			vidMem.digit[VidPos.posbody].color = Display
					.Instance().colMode1.col();
		}

		if (VidPos.posbody % xSize != 0)
			VidPos.posbody += (xSize - VidPos.posbody
					% xSize);
		else
			VidPos.posbody += xSize;
	}

	public void println(String str) {
		print(str);
		println();
	}

	public void println(char c) {
		print(c);
		println();
	}

	public void println(int i) {
		print(i);
		println();
	}

	public void println(long l) {
		print(l);
		println();
	}

	public void clearScreen(int bg) {

		if (mode == 0) {
			Display.Instance().colMode0.setColor(0, bg);
			VidPos.poshead = start;
			for (int j = start; j < end; j++)
				print(' ');
		}
		if (mode == 1) {
			Display.Instance().colMode1.setColor(0, bg);
			VidPos.posbody = start;
			for (int j = start; j < end; j++)
				print(' ');
		}
		if (mode == 2) {
			Display.Instance().colMode2.setColor(0, bg);
			VidPos.posfoot = start;
			for (int j = start; j < end; j++)
				print(' ');
		}
	}

	private void rekint2char(int x) {
		int c;
		// Rekrusiv Abbruch bei x == 0
		if (x != 0) {
			rekint2char(x / 10);
			c = (x >= 0) ? (x % 10) : (x % 10) * -1;
			print((char) (c + aciiPosInt));
		}
	}

	private void reklong2char(long x) {
		long c;
		// Rekrusiv Abbruch bei x == 0
		if (x != 0) {
			reklong2char(x / 10);
			c = (x >= 0) ? (x % 10) : (x % 10) * -1;
			print((char) (c + aciiPosInt));
		}
	}

	public static void directPrintln(int value, int base, int len, int x,
			int y, int col) {
	}

	public static void directPrintChar(char c, int x, int y, int fg, int bg) {
		int pos = x + 160 * y;
		if (pos < 0 || pos >= 2000)
			pos = 0;
		pos += VIDSTART;
		MAGIC.wMem8(pos++, (byte) c);
		MAGIC.wMem8(pos, Color.getColor(fg, bg));
	}

	public static void directprintHex(long l, int x, int y, int fg, int bg) {
		long m = 0;
		// Rekursion mit Abbruchbedingung bei == 0
		if ((m = l >>> 4) != 0)
			directprintHex(m, x, y, fg, bg);

		directPrintChar((char) ((m = l & 0x0F) + (m < 10 ? aciiPosInt
				: aciiPosHex)), x, y, fg, bg);
	}

	public static void directprintHex(int i, int x, int y, int fg, int bg) {
		int m = 0;
		// Rekursion mit Abbruchbedingung bei == 0
		if ((m = i >>> 4) != 0)
			directprintHex(m, x, y, fg, bg);

		directPrintChar((char) ((m = i & 0x0F) + (m < 10 ? aciiPosInt
				: aciiPosHex)), x, y, fg, bg);
	}

	public static void directPrintString(String s, int x, int y, int col) {
	}

	public static void directclearScreen(int mode, int bg) {
		int pos = VIDSTART;
		char c = ' ';
		if (mode == 0) {
			for (int j = 0; j < 80; j++) {
				MAGIC.wMem8(pos++, (byte) c);
				MAGIC.wMem8(pos++, Color.getColor(0, bg));
			}
		}
		if (mode == 1) {
			pos += 160;
			for (int j = 80; j < 1920; j++) {
				MAGIC.wMem8(pos++, (byte) c);
				MAGIC.wMem8(pos++, Color.getColor(0, bg));
			}
		}
		if (mode == 2) {
			pos += 3840;
			for (int j = 1920; j < 2000; j++) {
				MAGIC.wMem8(pos++, (byte) c);
				MAGIC.wMem8(pos++, Color.getColor(0, bg));
			}
		}
	}

	public static void setPixel(int x, int y, int color) {
		int start = 0xA0000;

		start += x + (y * 320);
		MAGIC.wMem8(start, (byte) color);
	}

	public static void rasterCircle(int x0, int y0, int radius, int color) {
		int f = 1 - radius;
		int ddF_x = 0;
		int ddF_y = -2 * radius;
		int x = 0;
		int y = radius;

		setPixel(x0, y0 + radius, color);
		setPixel(x0, y0 - radius, color);
		setPixel(x0 + radius, y0, color);
		setPixel(x0 - radius, y0, color);

		while (x < y) {
			if (f >= 0) {
				y--;
				ddF_y += 2;
				f += ddF_y;
			}
			x++;
			ddF_x += 2;
			f += ddF_x + 1;

			setPixel(x0 + x, y0 + y, color);
			setPixel(x0 - x, y0 + y, color);
			setPixel(x0 + x, y0 - y, color);
			setPixel(x0 - x, y0 - y, color);
			setPixel(x0 + y, y0 + x, color);
			setPixel(x0 - y, y0 + x, color);
			setPixel(x0 + y, y0 - x, color);
			setPixel(x0 - y, y0 - x, color);
		}
	}

}