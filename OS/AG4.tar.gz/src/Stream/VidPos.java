package Stream;

// Singelton Pattern
public class VidPos {

private static VidPos instance = null;
private VidPos(){}

public static VidPos getInstance()
{
    if (instance == null) {
        instance = new VidPos();
    }
    return instance;
}

public static int posbody;
public static int poshead;
public static int posfoot;
}
