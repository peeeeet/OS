package Stream;

public class Colors {

	public final static int grey = 0x07;
	public final static int brown = 0x06;
	public final static int viol = 0x05;
	public final static int red = 0x04;
	public final static int tur = 0x03;
	public final static int green = 0x02;
	public final static int blue = 0x01;
	public final static int black = 0x00;
	public final static int yellow = 0x0D;
	public final static int organge = 0x2C;
	public final static int lightred = 0x29;
	public final static int white = 0x0F;
	
}
