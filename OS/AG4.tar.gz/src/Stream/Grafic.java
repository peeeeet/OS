package Stream;
import kernel.BIOS;
import kernel.Interrupt;

public class Grafic {

public static void biosScreen()
{	
	
	// Muster
	for(int i=0;i < 200;i++)
	{
		for(int j=0; j<320;j++)
			Output.setPixel(j, i, Colors.blue);
	}
	
	for(int i=20;i>=0;i--)
		Output.rasterCircle(200, 100, i, Colors.black); // yellow 0x2D
	
	for(int i=30;i>=0;i--)
		Output.rasterCircle(60, 120, i, Colors.black); // organge 0x2C
	
	for(int i=30;i>=0;i--)
		Output.rasterCircle(240, 80, i, Colors.black); // organge 0x2C
	
	for(int i=20;i>=0;i--)
		Output.rasterCircle(100, 100, i, Colors.black); // organge/red 0x2B
	
	for(int i=40;i>=0;i--)
		Output.rasterCircle(150, 100, i, Colors.black); // 
	
	for(int i=0; i<60;i++)
	{
		for(int j=0;j<320;j++)
		{
		Output.setPixel(j,i,Colors.black);
		}
	}
	
	for(int i=140;i < 200;i++)
	{
		for(int j=0;j<320;j++)
			Output.setPixel(j, i, Colors.black);			
	}
	
	for(int i=20;i>=0;i--)
		Output.rasterCircle(140, 30, i, Colors.blue); // organge 0x2C
	


	for(int i=10;i>=0;i--)
		Output.rasterCircle(140, 30, i, Colors.black); // organge 0x2C
	
	// S kreise
	Output.rasterCircle(180, 40, 10, Colors.blue); // 
	Output.rasterCircle(180, 21, 10, Colors.blue); // organge 0x2C

	
	// S quadrad
	for(int i=178;i < 195;i++)
	{
		for(int j=21;j<30;j++)
			Output.setPixel(i, j, Colors.black);			
	}
	// S quadrat
	for(int i=163;i < 175;i++)
	{
		for(int j=31;j<40;j++)
			Output.setPixel(i, j, Colors.black);			
	}
	
}
	
}
