package devices;

public class Code {

	public byte val1;
	public byte val2;
	public byte val3;
	public int count = 0;
	
}
