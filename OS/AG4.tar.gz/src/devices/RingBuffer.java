package devices;

import Stream.Colors;
import Stream.Output;

public class RingBuffer {
	

private Code buffer[];
private int curPos = 0;
private int readPos = 0;
private int count = 0;
private final int size = 50;
private Output out;

public void init()
{
	buffer = new Code[size];
	out = new Output();
}

public int getPos()
{
	return curPos;
}

public int getreadPos()
{
	return readPos;
}

public int getCount()
{
	return count;
}

public void add(byte val1)
{
	
	out.setMode(1);
	if(curPos == size || curPos > size) curPos = 0;
	buffer[curPos].count = 1;
	buffer[curPos++].val1 = val1;	
	count++;
}

public void add(byte val1, byte val2)
{
	if(curPos == size || curPos > size) curPos = 0;
	buffer[curPos].count = 2;
	buffer[curPos].val1 = val1;
	buffer[curPos++].val2 = val2;
	count++;
}

public void add(byte val1, byte val2, byte val3)
{
	if(curPos == size || curPos > size) curPos = 0;
	buffer[curPos].count = 3;
	buffer[curPos].val1 = val1;
	buffer[curPos].val2 = val2;
	buffer[curPos++].val3 = val3;
	count++;
}

public Code getCode()
{
	Code c = buffer[readPos];
	buffer[readPos++] = null;
	count--;
	if(readPos == size || readPos > size) readPos = 0;
	return c;

}



}
