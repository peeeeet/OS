package devices;

import kernel.Display;
import Stream.Colors;
import Stream.Output;

public class Keyboard {

	private boolean caps = false;
	private boolean numb = false;
	private boolean scrolllock = false;

	public void decodInput(Code cod) {

		Display.Instance().outfoot.setCursorAbs(40, 0);
		Display.Instance().outfoot.print(cod.count);

		if (cod.count == 1) {
			if (caps)
				Display.Instance().outbody.print(getregularCapSymbol(cod));
			else
				Display.Instance().outbody.print(getregularSymbol(cod));

		} else if (cod.count == 2) {
			Display.Instance().outbody.print(get2byteSymbol(cod));
		} else if (cod.count == 3) {
			Display.Instance().outbody.print(get3byteSymbol(cod));
		}
	}

	public String getregularSymbol(Code cod) {
		int val = (int) cod.val1;
		val = val & 0x000000FF;
		String symbol = null;
		switch (val) {
		case 0x01:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[ESC]    ");
			break;
		case 0x02:
			symbol = "1";
			break;
		case 0x03:
			symbol = "2";
			break;
		case 0x04:
			symbol = "3";
			break;
		case 0x05:
			symbol = "4";
			break;
		case 0x06:
			symbol = "5";
			break;
		case 0x07:
			symbol = "6";
			break;
		case 0x08:
			symbol = "7";
			break;
		case 0x09:
			symbol = "8";
			break;
		case 0x0A:
			symbol = "9";
			break;
		case 0x0B:
			symbol = "0";
			break;
		case 0x0C:
			symbol = "ß";
			break;
		case 0x0D:
			symbol = "`";
			break;
		case 0x0E: // Function Return
			Display.Instance().outbody.setCursor(-1, 0);
			Display.Instance().outbody.print("  ");
			Display.Instance().outbody.setCursor(-2, 0);
			break;
		case 0x0F:
			Display.Instance().outbody.print("      "); // Function Tab
			break;
		case 0x10:
			symbol = "q";
			break;
		case 0x11:
			symbol = "w";
			break;
		case 0x12:
			symbol = "e";
			break;
		case 0x13:
			symbol = "r";
			break;
		case 0x14:
			symbol = "t";
			break;
		case 0x15:
			symbol = "z";
			break;
		case 0x16:
			symbol = "u";
			break;
		case 0x17:
			symbol = "i";
			break;
		case 0x18:
			symbol = "o";
			break;
		case 0x19:
			symbol = "p";
			break;
		case 0x1A:
			symbol = "ü";
			break;
		case 0x1B:
			symbol = "*";
			break;
		case 0x1C:
			Display.Instance().outbody.printNewLine(); // Function Enter
			break;
		case 0x1D:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[STRG]   ");
			// Function STRG
			break;
		case 0x1E:
			symbol = "a";
			break;
		case 0x1F:
			symbol = "s";
			break;
		case 0x20:
			symbol = "d";
			break;
		case 0x21:
			symbol = "f";
			break;
		case 0x22:
			symbol = "g";
			break;
		case 0x23:
			symbol = "h";
			break;
		case 0x24:
			symbol = "j";
			break;
		case 0x25:
			symbol = "k";
			break;
		case 0x26:
			symbol = "l";
			break;
		case 0x27:
			symbol = "ö";
			break;
		case 0x28:
			symbol = "ä";
			break;
		case 0x29:
			symbol = "^";
			break;
		case 0x2A:
			caps = true; // Function Groß
			break;
		case 0x2B:
			symbol = "#"; // 43
			break;
		case 0x2C:
			symbol = "y";
			break;
		case 0x2D:
			symbol = "x";
			break;
		case 0x2E:
			symbol = "c";
			break;
		case 0x2F:
			symbol = "v";
			break;
		case 0x30:
			symbol = "b";
			break;
		case 0x31:
			symbol = "n";
			break;
		case 0x32:
			symbol = "m";
			break;
		case 0x33:
			symbol = ",";
			break;
		case 0x34:
			symbol = ".";
			break;
		case 0x35:
			symbol = "-"; // Function Strich 53
			break;
		case 0x36:
			caps = true; // Function Groß 54
			break;
		case 0x37:
			symbol = "*"; // Function 55
			break;
		case 0x38:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[Alt Gr] ");
			// Function AltGr 56
			break;
		case 0x39:
			Display.Instance().outbody.setSpace(); // Function Space 57
			break;
		case 0x3A:
			Display.Instance().outhead.setCursorAbs(60, 0);
			Display.Instance().outhead.print("[Caps]   ");
			caps = true; // Function Capslock 58
			break;
		case 0x3B:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F1]     ");
			// Function F1 59
			break;
		case 0x3C:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F2]     ");
			// Function F2 60
			break;
		case 0x3D:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F3]     ");
			// Function F3 61
			break;
		case 0x3E:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F4]     ");
			// Function F4 62
			break;
		case 0x3F:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F5]     ");
			// Function F5 63
			break;
		case 0x40:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F6]     ");
			// Function F6 64
			break;
		case 0x41:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F7]     ");
			// Function F7 65
			break;
		case 0x42:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F8]     ");
			// Function F8 66
			break;
		case 0x43:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F9]     ");
			// Function F9 67
			break;
		case 0x44:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F10]    ");
			// Function F10 68
			break;
		case 0x45:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Num]    ");
				// Function Number 69
				numb = true;
			} else {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("       ");
				// Function Number 69
				numb = false;
			}
			break;
		case 0x46:
			if (this.scrolllock == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Rollen] ");
				// Function Rollen runter 70
				this.scrolllock = true;
			} else {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("       ");
				// Function Rollen runter 70
				this.scrolllock = false;
			}
			break;
		case 0x47:
			if (numb == false) {
				Display.Instance().outbody.setPos1(); // Function Pos1 71 // mit
														// Num Zahl 7
			} else
				symbol = "7";
			break;
		case 0x48:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil U]");
				// Function Pfeil Oben 72 // mit Num Zahl 8
				Display.Instance().outbody.setCursor(0, -1);
			} else
				symbol = "8";
			break;
		case 0x49:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Bild O] ");
				// Function Bild Oben 73 // mit Num Zahl 9
			} else
				symbol = "9";
			break;
		case 0x4A:
			symbol = "-"; // Function Strich 74
			break;
		case 0x4B:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil L]");
				// Function Pfeil links 75 // mit Num Zahl 4
				Display.Instance().outbody.setCursor(-1, 0);
			} else
				symbol = "4";
			break;
		case 0x4C:
			if (numb == true) // Function mit Num Zahl 5 76
				symbol = "5";
			break;
		case 0x4D:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil R]");
				// Function Pfeil rechts 77 // mit Num Zahl 6
				Display.Instance().outbody.setCursor(1, 0);
			} else
				symbol = "6";
			break;
		case 0x4E:
			symbol = "+"; // Function Plus 78
			break;
		case 0x4F:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[End]    ");
				// Function End 79 // mit Num Zahl 1
			} else
				symbol = "1";
			break;
		case 0x50:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil O]");
				// Function Pfeil runter 80 // mit Num Zahl 2
				Display.Instance().outbody.setCursor(0, 1);
			} else
				symbol = "2";

			break;
		case 0x51:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Bild D] ");
				// Function Bild runter 81 // mit Num Zahl 3
			} else
				symbol = "3";
			break;
		case 0x52:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Einf]   ");
				// Function Einf 82 // mit Num Zahl 0
			} else
				symbol = "0";
			break;
		case 0x53:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Entf]   ");
				// Function Entf 83 // mit Num Zahl ,
				Display.Instance().outbody.removeChar();
			} else
				symbol = ",";
			break;
		case 0x54:
			symbol = ""; // Function Nicht belegt 84
			break;
		case 0x55:
			symbol = ""; // Function Nicht belegt 85
			break;
		case 0x56:
			symbol = "<"; // Function < 86
			break;
		case 0x57:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F11]   ");
			// Function F11 87
			break;
		case 0x58:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F12]    ");
			// Function F12 88
			break;
		case 0x5D:
			symbol = ""; // Function WIN 91
			break;
		case 0x5E:
			symbol = ""; // Function WIN 92
			break;
		case 0x5F:
			symbol = ""; // Function Rechtklick 93
			break;
		}
		return symbol;
	}

	public String getregularCapSymbol(Code cod) {
		int val = (int) cod.val1;
		val = val & 0x000000FF;
		String symbol = null;
		switch (val) {
		case 0x01:
			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[ESC]    ");
			break;
		case 0x02:
			symbol = "!";
			break;
		case 0x03:
			symbol = "\"";
			break;
		case 0x04:
			symbol = "§";
			break;
		case 0x05:
			symbol = "$";
			break;
		case 0x06:
			symbol = "%";
			break;
		case 0x07:
			symbol = "&";
			break;
		case 0x08:
			symbol = "/";
			break;
		case 0x09:
			symbol = "(";
			break;
		case 0x0A:
			symbol = ")";
			break;
		case 0x0B:
			symbol = "=";
			break;
		case 0x0C:
			symbol = "?";
			break;
		case 0x0D:
			symbol = "`";
			break;
		case 0x0E: // Function Return
			Display.Instance().outbody.setCursor(-1, 0);
			Display.Instance().outbody.print("  ");
			Display.Instance().outbody.setCursor(-2, 0);
			break;
		case 0x0F:
			Display.Instance().outbody.print("      "); // Function Tab
			break;
		case 0x10:
			symbol = "Q";
			break;
		case 0x11:
			symbol = "W";
			break;
		case 0x12:
			symbol = "E";
			break;
		case 0x13:
			symbol = "R";
			break;
		case 0x14:
			symbol = "T";
			break;
		case 0x15:
			symbol = "Z";
			break;
		case 0x16:
			symbol = "U";
			break;
		case 0x17:
			symbol = "I";
			break;
		case 0x18:
			symbol = "O";
			break;
		case 0x19:
			symbol = "P";
			break;
		case 0x1A:
			symbol = "Ü";
			break;
		case 0x1B:
			symbol = "*";
			break;
		case 0x1C:
			Display.Instance().outbody.printNewLine(); // Function Enter
			break;
		case 0x1D:
			symbol = ""; // Function STRG
			break;
		case 0x1E:
			symbol = "A";
			break;
		case 0x1F:
			symbol = "S";
			break;
		case 0x20:
			symbol = "D";
			break;
		case 0x21:
			symbol = "F";
			break;
		case 0x22:
			symbol = "G";
			break;
		case 0x23:
			symbol = "H";
			break;
		case 0x24:
			symbol = "J";
			break;
		case 0x25:
			symbol = "K";
			break;
		case 0x26:
			symbol = "L";
			break;
		case 0x27:
			symbol = "Ö";
			break;
		case 0x28:
			symbol = "Ä";
			break;
		case 0x29:
			symbol = "°";
			break;
		case 0xAA:
			caps = false; // Function Groß
			break;
		case 0x2B:
			symbol = "'";
			break;
		case 0x2C:
			symbol = "Y";
			break;
		case 0x2D:
			symbol = "X";
			break;
		case 0x2E:
			symbol = "C";
			break;
		case 0x2F:
			symbol = "V";
			break;
		case 0x30:
			symbol = "B";
			break;
		case 0x31:
			symbol = "N";
			break;
		case 0x32:
			symbol = "M";
			break;
		case 0x33:
			symbol = ";";
			break;
		case 0x34:
			symbol = ":";
			break;
		case 0x35:
			symbol = "_"; // Function Strich 53
			break;
		case 0xB6:
			caps = false; // Function Groß 54
			break;
		case 0x37:
			symbol = "*"; // Function 55
			break;
		case 0x38:
			symbol = ""; // Function AltGr 56
			break;
		case 0x39:
			Display.Instance().outbody.setSpace();
			break;
		case 0x3A:
			Display.Instance().outhead.setCursorAbs(60, 0);
			Display.Instance().outhead.print("         ");
			caps = false; // Function Capslock 58
			break;
		case 0x3B:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F1]     ");
			// Function F1 59
			break;
		case 0x3C:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F2]     ");
			// Function F2 60
			break;
		case 0x3D:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F3]     ");
			// Function F3 61
			break;
		case 0x3E:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F4]     ");
			// Function F4 62
			break;
		case 0x3F:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F5]     ");
			// Function F5 63
			break;
		case 0x40:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F6]     ");
			// Function F6 64
			break;
		case 0x41:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F7]     ");
			// Function F7 65
			break;
		case 0x42:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F8]     ");
			// Function F8 66
			break;
		case 0x43:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F9]     ");
			// Function F9 67
			break;
		case 0x44:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F10]    ");
			// Function F10 68
			break;
		case 0x45:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Num]    ");
				// Function Number 69
				numb = true;
			} else {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("         ");
				// Function Number 69
				numb = false;
			}
			break;
		case 0x46:
			if (this.scrolllock == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Rollen] ");
				// Function Rollen runter 70
				this.scrolllock = true;
			} else {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("         ");
				// Function Rollen runter 70
				this.scrolllock = false;
			}
			break;
		case 0x47:
			if (numb == false) {
				Display.Instance().outbody.setPos1(); // Function Pos1 71 // mit
														// Num Zahl 7
			} else
				symbol = "7";
			break;
		case 0x48:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil O]");
				// Function Pfeil Oben 72 // mit Num Zahl 8
				Display.Instance().outbody.setCursor(0, -1);
			} else
				symbol = "8";
			break;
		case 0x49:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Bild O] ");
				// Function Bild Oben 73 // mit Num Zahl 9
			} else
				symbol = "9";
			break;
		case 0x4A:
			symbol = "-"; // Function Strich 74
			break;
		case 0x4B:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil L]");
				// Function Pfeil links 75 // mit Num Zahl 4
				Display.Instance().outbody.setCursor(-1, 0);
			} else
				symbol = "4";
			break;
		case 0x4C:
			if (numb == true) // Function mit Num Zahl 5 76
				symbol = "5";
			break;
		case 0x4D:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil R]");
				// Function Pfeil rechts 77 // mit Num Zahl 6
				Display.Instance().outbody.setCursor(1, 0);
			} else
				symbol = "6";
			break;
		case 0x4E:
			symbol = "+"; // Function Plus 78
			break;
		case 0x4F:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[End]    ");
				// Function End 79 // mit Num Zahl 1
			} else
				symbol = "1";
			break;
		case 0x50:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Pfeil O]");
				// Function Pfeil runter 80 // mit Num Zahl 2
				Display.Instance().outbody.setCursor(0, 1);
			} else
				symbol = "2";

			break;
		case 0x51:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Bild D] ");
				// Function Bild runter 81 // mit Num Zahl 3
			} else
				symbol = "3";
			break;
		case 0x52:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Einf]   ");
				// Function Einf 82 // mit Num Zahl 0
			} else
				symbol = "0";
			break;
		case 0x53:
			if (numb == false) {

				Display.Instance().outhead.setCursorAbs(0, 0);
				Display.Instance().outhead.print("[Entf]   ");
				// Function Entf 83 // mit Num Zahl ,
				Display.Instance().outbody.removeChar();
			} else
				symbol = ",";
			break;
		case 0x54:
			symbol = ""; // Function Nicht belegt 84
			break;
		case 0x55:
			symbol = ""; // Function Nicht belegt 85
			break;
		case 0x56:
			symbol = ">"; // Function < 86
			break;
		case 0x57:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F11]    ");
			// Function F11 87
			break;
		case 0x58:

			Display.Instance().outhead.setCursorAbs(0, 0);
			Display.Instance().outhead.print("[F12]    ");
			// Function F12 88
			break;
		case 0x5D:
			symbol = ""; // Function WIN 91
			break;
		case 0x5E:
			symbol = ""; // Function WIN 92
			break;
		case 0x5F:
			symbol = ""; // Function Rechtklick 93
			break;
		}
		return symbol;
	}

	public String get2byteSymbol(Code cod) {
		String symbol = null;
		Display.Instance().outhead.printHex(cod.val1);
		Display.Instance().outhead.print(" ");
		Display.Instance().outhead.printHex(cod.val2);
		Display.Instance().outhead.println();
		switch (cod.val1) {
		case 0x01:
			symbol = "ESC";
			break;
		case 0x02:
			symbol = "1";
			break;
		case 0x03:
			symbol = "2";
			break;
		case 0x04:
			symbol = "3";
			break;
		case 0x05:
			symbol = "4";
			break;
		case 0x06:
			symbol = "5";
			break;
		case 0x07:
			symbol = "6";
			break;
		case 0x08:
			symbol = "7";
			break;
		case 0x09:
			symbol = "8";
			break;
		case 0x0A:
			symbol = "9";
			break;
		case 0x0B:
			symbol = "0";
			break;

		}
		return symbol;
	}

	public String get3byteSymbol(Code cod) {
		String symbol = null;
		switch (cod.val1) {
		case 0x01:
			symbol = "ESC";
			break;
		case 0x02:
			symbol = "1";
			break;
		case 0x03:
			symbol = "2";
			break;
		case 0x04:
			symbol = "3";
			break;
		case 0x05:
			symbol = "4";
			break;
		case 0x06:
			symbol = "5";
			break;
		case 0x07:
			symbol = "6";
			break;
		case 0x08:
			symbol = "7";
			break;
		case 0x09:
			symbol = "8";
			break;
		case 0x0A:
			symbol = "9";
			break;
		case 0x0B:
			symbol = "0";
			break;

		}
		return symbol;
	}

}
