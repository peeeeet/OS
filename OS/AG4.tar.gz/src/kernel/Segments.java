package kernel;

public class Segments {
	
	private static int startAddress;
	
	public static void init()
	{
		
		
	}

	
	public static int getStartAddress()
	{		
		return startAddress;
	}	


}
