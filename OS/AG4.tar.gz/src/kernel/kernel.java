package kernel;
import Stream.Grafic;
import Stream.Output;
import Stream.Colors;
import Stream.VidMem;
import rte.MemMap;
public class Kernel {
	
private static Interrupt INTController;
private static int count = 0;

	public static void main()
	{
		
		// Speicherbereich aufteilen
		Segments.init();

		
		// VGA Modus
		Display.vgaMode();
		// Bios Screen
		Grafic.biosScreen();
		// Text Modus
		Display.textMode();
		// Clear Screen
		Output.directclearScreen(0, Colors.black);
		Output.directclearScreen(1, Colors.white);
		Output.directclearScreen(2, Colors.black);
		//4c
		getMemoryMap();
		//Display & Interrupt init
		Display.Instance().init();
		Interrupt.init();	
	}
	
	private static void getMemoryMap()
	{
		int i = 3;
		int type;
		long base;
		long leng;
		int startAdd = 0x0E780;
		BIOS.regs.EBX=0x00;
		do
		{
		BIOS.regs.EAX=0x0000E820;
		BIOS.regs.EDX=0x534D4150;
		BIOS.regs.ECX=0x14;
		BIOS.regs.ES=0x0;
		BIOS.regs.EDI=startAdd;
		BIOS.rint(0x15);
		base = MAGIC.rMem64(startAdd);
		leng = MAGIC.rMem64(startAdd+8);
		type = MAGIC.rMem32(startAdd+16);
		if(type == 1)
		{
		Output.directprintHex(base, 0, i, Colors.white, Colors.green);
		Output.directprintHex(leng, 10, i, Colors.white, Colors.green);
		Output.directprintHex(type, 20, i, Colors.white, Colors.green);
		}
		if(type == 2)
		{
		Output.directprintHex(base, 0, i, Colors.white, Colors.red);
		Output.directprintHex(leng, 10, i, Colors.white, Colors.red);
		Output.directprintHex(type, 20, i, Colors.white, Colors.red);
		}
		i++;
		}
		while(BIOS.regs.EBX!=0x00);
	}
	
}
