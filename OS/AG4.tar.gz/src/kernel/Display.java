package kernel;

import Stream.Color;
import Stream.Colors;
import Stream.Output;
import Stream.VidPos;

public class Display {

	public Color colMode0 = null;
	public Color colMode1 = null;
	public Color colMode2 = null;
	public Color colTrigMode0 = null; 
	public Color colTrigMode1 = null; 
	public Color colTrigMode2 = null;
	public Output outhead = null;
	public Output outbody = null;
	public Output outfoot = null;


private static Display instance = null;
private Display(){}

public static Display Instance()
{
    if (instance == null) {
        instance = new Display();
    }
    return instance;
}
	
public void init()
{
	outhead = new Output(0);
	outbody = new Output(1);
	outfoot = new Output(2);
	colMode0 = new Color(Colors.green,Colors.black);
	colMode1 = new Color(Colors.green,Colors.white);
	colMode2 = new Color(Colors.green,Colors.black);
	colTrigMode0 = new Color(Colors.black,Colors.green);
	colTrigMode1 = new Color(Colors.white,Colors.green);
	colTrigMode2 = new Color(Colors.black,Colors.green);
}
	
public static void vgaMode()
{
	BIOS.regs.EAX=0x0013;
	BIOS.rint(0x10);	
}
	
public static void textMode()
{
	BIOS.regs.EAX=0x0003;
	BIOS.rint(0x10);
}
/*
public static Color getcolMode0()
{
    if (colMode0 == null) {
    	
    }
    return colMode0;
}

public static Color getcolMode1()
{
    if (colMode1 == null) {
    	colMode1 = new Color(Colors.black,Colors.white);
    }
    return colMode1;
}

public static Color getcolMode2()
{
    if (colMode2 == null) {
    	colMode2 = new Color(Colors.black,Colors.white);
    }
    return colMode2;
}

public static Color getcolTrigMode0()
{
    if (colTrigMode0 == null) {
    	colTrigMode0 = new Color(Colors.black,Colors.green);
    }
    return colTrigMode0;
}

public static Color getcolTrigMode1()
{
    if (colTrigMode1 == null) {
    	colTrigMode1 = new Color(Colors.black,Colors.white);
    }
    return colTrigMode1;
}

public static Color getcolTrigMode2()
{
    if (colTrigMode2 == null) {
    	colTrigMode2 = new Color(Colors.green,Colors.black);
    }
    return colTrigMode2;
}

public static Output getouthead()
{
    if (outhead== null) {
    	outhead = new Output(0);
    }
    return outhead;
}

public static Output getoutbody()
{
    if (outbody== null) {
    	outbody = new Output(1);
    }
    return outbody;
}

public static Output getoutfoot()
{
    if (outfoot== null) {
    	
    }
    return outfoot;
}
*/	
}
