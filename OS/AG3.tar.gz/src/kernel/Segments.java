package kernel;

public class Segments {
	
	private static int nextFreeAddress;
	private static int startIDTAdd;
	private static int endIDTAdd;
	
	public static void init()
	{
		// Start Adresse abrufen
		int startAddress = MAGIC.imageBase + MAGIC.rMem32(MAGIC.imageBase + 4);
		// Auf 4Byte Alignieren
		while(startAddress % 4 != 0) startAddress++;
		// Speicher für IDT festlegen
		startIDTAdd = startAddress;
		endIDTAdd = startIDTAdd+Interrupt.getTableLimit();
		// Speicher für NewInstace bereitstellen
		nextFreeAddress = endIDTAdd + 4;	
	}

	public static int getnextFreeAddress()
	{		
		return nextFreeAddress;
	}
	
	public static int getstartIDTAdd()
	{		
		return startIDTAdd;
	}	

	public static int getendIDTAdd()
	{		
		return endIDTAdd;
	}

}
