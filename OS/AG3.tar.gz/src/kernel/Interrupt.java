package kernel;

import Stream.Output;
import rte.DynamicRuntime;


public class Interrupt {
private final static int MASTER = 0x20;
private final static int SLAVE = 0xA0;
private static int curAdd;
private static int tableLimit = 48*8;
private static int mask = 0x8E00; // 1000 1110 0000 0000

public static int getTableLimit()
{
	return tableLimit;
}

public static void init()
{
	//Debug output
	//Output out = new Output();
	int baseAddress = Segments.getstartIDTAdd();
	curAdd = baseAddress;
	//out.print("Table Start Address: ");
	//out.print(baseAddress);
	//out.println();
	//out.print("Table End Address: ");
	//out.println(Segments.getendIDTAdd());
	initPic();
	buildIntTable();
	loadDescTable(baseAddress, tableLimit);
	//activateInterrupts();
	
}

public static void buildIntTable()
{
// Codestart Methode Interrupt Handler1
int mthadd1, mthadd2, mthadd3, mthadd4;	
mthadd1 = MAGIC.rMem32(MAGIC.cast2Ref(MAGIC.clssDesc("Interrupt"))+MAGIC.mthdOff("Interrupt","HandlerEx07" ))+MAGIC.getCodeOff();
mthadd2 = MAGIC.rMem32(MAGIC.cast2Ref(MAGIC.clssDesc("Interrupt"))+MAGIC.mthdOff("Interrupt","HandlerEx14" ))+MAGIC.getCodeOff();
mthadd3 = MAGIC.rMem32(MAGIC.cast2Ref(MAGIC.clssDesc("Interrupt"))+MAGIC.mthdOff("Interrupt","HandlerInt" ))+MAGIC.getCodeOff();

// TEST 
//Debug.MethCall(mthadd1);

// Exception 0 - 6
for(int i = 0; i < 8;i++)
	buildEntry(i,mthadd1);

// Exception 
for(int i = 7; i < 19;i++)
	buildEntry(i,mthadd2);

// Interrupt
for(int i = 20; i < 48; i++)
	buildEntry(i,mthadd3);
	
}

public static void buildEntry(int seg, int offset)
{
	// IDT Maske setzen
	//Debug output
	//Output out = new Output();
	int add1, add2;
	int off1, off2;
	
	//out.print("MetOff: ");
	//out.printHex(offset);
	//out.print(" | ");
	
	// Segment Selector auf 31- 16
	add1 = seg << 16;
	//out.print("Seg: ");
	//out.printHex(add1);
	//out.print(" | ");
	
	// Offset 0-15
	off1 = offset & 0x0000FFFF;
	//out.print("Os1: ");
	//out.printHex(off1);
	//out.print(" | ");
	
	//Offset 16-31
	off2 = offset & 0xFFFF0000;
	//out.print("Os2: ");
	//out.printHex(off2);
	//out.print(" | ");
	
	// 0 - 31 Teil1
	add1 = add1 | off1;
	//out.print("E1: ");
	//out.printHex(add1);
	//out.print(" | ");
	
	// 0 - 31 Teil2
	add2 = off2 | mask;
	//out.print("E2: ");
	//out.printHex(add2);
	//out.print(" | ");

	//out.print("Add 1: ");
	//out.print(curAdd);
	//out.print(" | ");
	
	// Schreiben
	MAGIC.wMem32(curAdd, add1);
	curAdd+=4;
	//out.print("Add 2: ");
	//out.print(curAdd);
	//out.print(" | ");
	MAGIC.wMem32(curAdd, add2);
	curAdd+=4;
	
	//out.print("Add: ");
	//out.print(curAdd);
	//out.print(" | ");
	
	//out.println();
}

public static void initPic()
{
	programmChip(MASTER,0x20,0x04);
	programmChip(SLAVE,0x28,0x02);
}
	
private static void programmChip(int port, int offset, int icw3)
{
	MAGIC.wIOs8(port++, (byte)0x11); // ICW1
	MAGIC.wIOs8(port, (byte)offset); // ICW2
	MAGIC.wIOs8(port, (byte)icw3);	// ICW3
	MAGIC.wIOs8(port, (byte)0x01);	// ICW4
}

private static void activateInterrupts()
{
MAGIC.inline(0xFB);
}

private static void deactivateInterrupts()
{
MAGIC.inline(0XFA);	
}

public static void loadDescTable(int baseAddress, int tableLimit)
{
	long tmp = (((long)baseAddress)<<16)|(long)tableLimit;
	MAGIC.inline(0x0F, 0x01, 0x5D);
	MAGIC.inlineOffset(1, tmp);
}



private static void confirmMAInterrupt()
{
	MAGIC.wIOs8(MASTER, (byte)0x20);
}

private static void confirmSLInterrupt()
{
	MAGIC.wIOs8(SLAVE, (byte)0x20);
}

public static void testException()
{
	MAGIC.inline(0xCC);
}

@SJC.Interrupt
public static void HandlerEx07()
{
Output.directPrintChar('X');
while(true);
	//confrimMAInterrupt();
}

@SJC.Interrupt
public static void HandlerEx14(int x)
{
	confirmSLInterrupt();
}


@SJC.Interrupt
public static void HandlerInt()
{
	confirmSLInterrupt();
}

}
