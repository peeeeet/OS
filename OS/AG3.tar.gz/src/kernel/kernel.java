package kernel;
import Stream.Output;
public class Kernel {
	
private static int grey = 0x07;
private static int brown = 0x06;
private static int viol = 0x05;
private static int red = 0x04;
private static int tur = 0x03;
private static int green = 0x02;
private static int blue = 0x01;
private static int black = 0x00;
private static Interrupt interrupt;


	
	public static void main()
	{
		Segments.init();
		TestInt();
		TestBIOS();
		Output out = new Output();
		out.clearScreen(green);
	}
	
	public static void TestInt()
	{
				
		interrupt.init();		
		// Fehler 
		//interrupt.testException();
		
	}
	
	public static void TestBIOS()
	{
		
		BIOS.regs.EAX=0x0013;
		BIOS.rint(0x10);
		
		
		// Muster
		for(int i=0;i < 200;i++)
		{
			for(int j=0; j<320;j++)
				Output.setPixel(j, i, blue);
		}
		
		for(int i=20;i>=0;i--)
			Output.rasterCircle(200, 100, i, black); // yellow 0x2D
		
		for(int i=30;i>=0;i--)
			Output.rasterCircle(60, 120, i, black); // organge 0x2C
		
		for(int i=30;i>=0;i--)
			Output.rasterCircle(240, 80, i, black); // organge 0x2C
		
		for(int i=20;i>=0;i--)
			Output.rasterCircle(100, 100, i, black); // organge/red 0x2B
		
		for(int i=40;i>=0;i--)
			Output.rasterCircle(150, 100, i, black); // red 0x29
		
		for(int i=0; i<60;i++)
		{
			for(int j=0;j<320;j++)
			{
			Output.setPixel(j,i,black);
			}
		}
		
		for(int i=140;i < 200;i++)
		{
			for(int j=0;j<320;j++)
				Output.setPixel(j, i, black);			
		}
		

			
		
		for(int i=20;i>=0;i--)
			Output.rasterCircle(140, 30, i, blue); // organge 0x2C
		


		for(int i=10;i>=0;i--)
			Output.rasterCircle(140, 30, i, black); // organge 0x2C
		
		// S kreise
		Output.rasterCircle(180, 40, 10, blue); // organge 0x2C
		Output.rasterCircle(180, 21, 10, blue); // organge 0x2C
	
		
		// S quadrad
		for(int i=178;i < 195;i++)
		{
			for(int j=21;j<30;j++)
				Output.setPixel(i, j, black);			
		}
		// S quadrat
		for(int i=163;i < 175;i++)
		{
			for(int j=31;j<40;j++)
				Output.setPixel(i, j, black);			
		}

		
		BIOS.regs.EAX=0x003;
		BIOS.rint(0x10);
		
	}

}
