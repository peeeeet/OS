package Stream;

public class Output
{
private static int vidSize = 2000;
private static int xSize = 80;
private static int ySize = 25;
private static int col = 0x02;
private static int aciiPosInt = 48;
private static int aciiPosHex = 55;
private VidMem vidMem=(VidMem)MAGIC.cast2Struct(0xB8000);	

public void setColor(int fg, int bg) 
{
col = getColor(fg,bg);
}
public void setCursorAbs(int newX, int newY) 
{
VidPos.getInstance().pos = 0;	
VidPos.getInstance().pos = VidPos.getInstance().pos + (newX + newY*xSize);	
if (VidPos.getInstance().pos<0 || VidPos.getInstance().pos>=vidSize) VidPos.getInstance().pos=0;
}
public void setCursor(int newX, int newY) 
{
int y = VidPos.getInstance().pos/xSize;
int x = VidPos.getInstance().pos%xSize;

y+= newY;
x+= newX;

VidPos.getInstance().pos = x + y*xSize;	
if (VidPos.getInstance().pos<0 || VidPos.getInstance().pos>=vidSize) VidPos.getInstance().pos=0;
}
public void print(String str) 
{	
for (int i=0; i<str.length(); i++)
	print(str.charAt(i));
}
public void print(char c) 
{
if (VidPos.getInstance().pos<0 || VidPos.getInstance().pos>=vidSize) VidPos.getInstance().pos=0;
vidMem.digit[VidPos.getInstance().pos].ascii=(byte)c;
vidMem.digit[VidPos.getInstance().pos++].color=(byte)col;
}
public void print(int x) 
{

// Schreibe - wenn x < 0
if(x < 0)
	print('-');

if(x != 0)
	{
	// Zahl in Char umwandeln
	rekint2char(x);
	}
// Wenn Zahl = 0 dann Sonderfall
else
	{
	print((char)(aciiPosInt));
	}
}
public void print(long x) 
{
	// Schreibe - wenn x < 0
	if(x < 0)
		print('-');

	if(x != 0)
		{
		// Zahl in Char umwandeln
		reklong2char(x);
		}
	// Wenn Zahl = 0 dann Sonderfall
	else
		{
		print((char)(aciiPosInt));
		}	

}

public void printHex(byte b) 
{
int m = 0;
// Rekursion mit Abbruchbedingung bei == 0
if( (m = b >>> 4) != 0 ) printHex( m );
				    
	print((char)((m=b & 0x0F)+(m<10 ? aciiPosInt : aciiPosHex)));	
}
public void printHex(short s) 
{
int m = 0;
// Rekursion mit Abbruchbedingung bei == 0
if( (m = s >>> 4) != 0 ) printHex( m );
			    
print((char)((m=s & 0x0F)+(m<10 ? aciiPosInt : aciiPosHex)));	
	
}
public void printHex(int x) 
{
int m = 0;
// Rekursion mit Abbruchbedingung bei == 0
if( (m = x >>> 4) != 0 ) printHex( m );
	    
print((char)((m=x & 0x0F)+(m<10 ? aciiPosInt : aciiPosHex)));
}
public void printHex(long x) 
{
long m = 0;
// Rekursion mit Abbruchbedingung bei == 0
if( (m = x >>> 4) != 0 ) printHex( m );
		    
print((char)((m=x & 0x0F)+(m<10 ? aciiPosInt : aciiPosHex)));	
}

public void println() 
{	 	
if(VidPos.getInstance().pos%xSize != 0  )
	VidPos.getInstance().pos += (xSize - VidPos.getInstance().pos%xSize);	
}
public void println(String str) 
{		
print(str);
println();
}
public void println(char c)
{	
print(c);	
println();	
}
public void println(int i)
{
print(i);
println();
}
public void println(long l)
{
print(l);
println();
}

public void clearScreen(int bg)
{
	col = getColor(0,bg);
	VidPos.getInstance().pos = 0;
	for(int j = 0;j<2000;j++)
		print(' ');
}

private void rekint2char(int x)
{
	  int c;
	  // Rekrusiv Abbruch bei x == 0
	  if(x != 0)
	  {
		  rekint2char(x/10);
		  c = (x >= 0)?(x%10):(x%10)*-1;
		  print((char)(c + aciiPosInt));
	  }	
}
private void reklong2char(long x)
{
	  long c;
	  // Rekrusiv Abbruch bei x == 0
	  if(x != 0)
	  {
		  reklong2char(x/10);
		  c = (x >= 0)?(x%10):(x%10)*-1;
		  print((char)(c + aciiPosInt));
	  }	
}
private static int getColor(int fg, int bg)
{
	  int color = bg;
	    // Color
	    // Set 4-6 Bits
	    color = color << 4;
	    // Set 0-2 Bits
	    color = color | fg;
	  
	  return color;
}

public static void directPrintln(int value, int base, int len, int x, int y, int col)
{}
public static void directPrintChar(char c)
{
int	vidpos=0xB9FFF;
MAGIC.wMem8(vidpos++, (byte)c);
MAGIC.wMem8(vidpos++, (byte)0x07);
}


public static void directPrintString(String s, int x, int y, int col)
{}

public static void setPixel(int x, int y, int color)
{
	int start = 0xA0000;
	
	start += x + (y*320);
	MAGIC.wMem8(start, (byte)color);	
}

public static void rasterCircle(int x0, int y0, int radius, int color)
{
  int f = 1 - radius;
  int ddF_x = 0;
  int ddF_y = -2 * radius;
  int x = 0;
  int y = radius;

  setPixel(x0, y0 + radius,color);
  setPixel(x0, y0 - radius,color);
  setPixel(x0 + radius, y0,color);
  setPixel(x0 - radius, y0,color);

  while(x < y)
  {
    if(f >= 0)
    {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x + 1;

    setPixel(x0 + x, y0 + y,color);
    setPixel(x0 - x, y0 + y,color);
    setPixel(x0 + x, y0 - y,color);
    setPixel(x0 - x, y0 - y,color);
    setPixel(x0 + y, y0 + x,color);
    setPixel(x0 - y, y0 + x,color);
    setPixel(x0 + y, y0 - x,color);
    setPixel(x0 - y, y0 - x,color);
  }
}

}